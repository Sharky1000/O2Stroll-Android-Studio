package com.example.o2stroll
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.o2stroll.databinding.FragmentSignupBinding

class SignupFragment : Fragment() {

    private var _binding: FragmentSignupBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSignupBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        (activity as? MainActivity)?.hideBottomNavigation()

        binding.signupButton.setOnClickListener {
            val name = binding.nameInput.text.toString()
            val email = binding.emailInput.text.toString()
            val password = binding.passwordInput.text.toString()
            val confirmPassword = binding.confirmPasswordInput.text.toString()

            when {
                name.isEmpty() || email.isEmpty() || password.isEmpty() -> {
                    Toast.makeText(context, "Please fill all fields", Toast.LENGTH_SHORT).show()
                }
                password != confirmPassword -> {
                    Toast.makeText(context, "Passwords don't match", Toast.LENGTH_SHORT).show()
                }
                password.length < 6 -> {
                    Toast.makeText(context, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show()
                }
                else -> {
                    (activity as? MainActivity)?.setLoggedIn(true)
                    saveUserInfo(name, email)
                    Toast.makeText(context, "Account created! Welcome 🌿", Toast.LENGTH_SHORT).show()
                    (activity as? MainActivity)?.navigateToHome()
                }
            }
        }

        binding.loginText.setOnClickListener {
            (activity as? MainActivity)?.navigateToLogin()
        }
    }

    private fun saveUserInfo(name: String, email: String) {
        val sharedPreferences = requireActivity().getSharedPreferences("o2strollPrefs", MODE_PRIVATE)
        sharedPreferences.edit().apply {
            putString("userName", name)
            putString("userEmail", email)
            apply()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
package com.example.o2stroll

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.o2stroll.databinding.FragmentAboutBinding

class AboutFragment : Fragment() {

    private var _binding: FragmentAboutBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAboutBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupAboutInfo()
        setupClickListeners()
    }

    private fun setupAboutInfo() {
        binding.appVersion.text = "Version 1.0.0"
        binding.appDescription.text = """
            O2Stroll helps you track and increase the time you spend in nature. 
            Research shows that spending time outdoors improves mental health, 
            reduces stress, and boosts overall wellbeing.
            
            Our mission is to reconnect people with nature, one adventure at a time.
        """.trimIndent()
    }

    private fun setupClickListeners() {
        binding.rateAppButton.setOnClickListener {
            Toast.makeText(context, "Opening Play Store...", Toast.LENGTH_SHORT).show()
            // In production: open Play Store
        }

        binding.shareAppButton.setOnClickListener {
            shareApp()
        }

        binding.websiteLink.setOnClickListener {
            openUrl("https://o2stroll.app")
        }

        binding.contactEmail.setOnClickListener {
            sendEmail("support@o2stroll.app")
        }

        binding.termsLink.setOnClickListener {
            Toast.makeText(context, "Terms of Service", Toast.LENGTH_SHORT).show()
        }

        binding.privacyLink.setOnClickListener {
            Toast.makeText(context, "Privacy Policy", Toast.LENGTH_SHORT).show()
        }

        binding.licensesButton.setOnClickListener {
            Toast.makeText(context, "Open Source Licenses", Toast.LENGTH_SHORT).show()
        }
    }

    private fun shareApp() {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Check out o2stroll!")
            putExtra(Intent.EXTRA_TEXT, "Track your outdoor adventures with o2stroll! 🌿")
        }
        startActivity(Intent.createChooser(shareIntent, "Share o2stroll"))
    }

    private fun openUrl(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Cannot open link", Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendEmail(email: String) {
        try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:$email")
                putExtra(Intent.EXTRA_SUBJECT, "o2stroll App Feedback")
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "No email app found", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
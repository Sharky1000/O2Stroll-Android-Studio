package com.example.o2stroll

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.o2stroll.databinding.FragmentHomeBinding
import java.util.*

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private var totalMinutesInNature = 0
    private var dailyGoalMinutes = 180
    private var isTracking = false
    private var currentStreak = 5

    private val handler = Handler(Looper.getMainLooper())
    private var timerRunnable: Runnable? = null

    private val quotes = arrayOf(
        Pair("In every walk with nature, one receives far more than he seeks.", "John Muir"),
        Pair("Nature does not hurry, yet everything is accomplished.", "Lao Tzu"),
        Pair("Look deep into nature, and then you will understand everything better.", "Albert Einstein"),
        Pair("The clearest way into the Universe is through a forest wilderness.", "John Muir")
    )

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        loadUserData()
        updateDisplay()
        loadRandomQuote()
        setupClickListeners()
    }

    private fun setupClickListeners() {
        binding.startTrackingButton.setOnClickListener {
            toggleTracking()
        }

        binding.quoteCard.setOnClickListener {
            loadRandomQuote()
        }

        binding.exploreNearbyButton.setOnClickListener {
            (activity as? MainActivity)?.loadFragment(ExploreFragment())
            (activity as? MainActivity)?.binding?.bottomNavigation?.selectedItemId = R.id.nav_explore
        }
    }

    private fun toggleTracking() {
        isTracking = !isTracking
        if (isTracking) {
            binding.startTrackingButton.text = "⏸ Pause Tracking"
            context?.let {
                binding.startTrackingButton.setBackgroundColor(
                    ContextCompat.getColor(it, R.color.orange)
                )
            }
            startTimer()
            Toast.makeText(context, "Tracking started! 🌿", Toast.LENGTH_SHORT).show()
        } else {
            binding.startTrackingButton.text = "▶ Start Tracking"
            context?.let {
                binding.startTrackingButton.setBackgroundColor(
                    ContextCompat.getColor(it, R.color.nature_green)
                )
            }
            stopTimer()
        }
    }

    private fun startTimer() {
        timerRunnable = object : Runnable {
            override fun run() {
                totalMinutesInNature++
                updateDisplay()
                saveUserData()
                handler.postDelayed(this, 60000)
            }
        }
        handler.post(timerRunnable!!)
    }

    private fun stopTimer() {
        timerRunnable?.let { handler.removeCallbacks(it) }
    }

    private fun updateDisplay() {
        val hours = totalMinutesInNature / 60
        val minutes = totalMinutesInNature % 60
        binding.timeDisplay.text = "${hours}h ${minutes}m"

        val progress = ((totalMinutesInNature.toFloat() / dailyGoalMinutes) * 100).toInt()
        binding.progressBar.progress = progress.coerceIn(0, 100)
        binding.progressText.text = "$progress% of daily goal"

        binding.streakDays.text = "$currentStreak Days"
        binding.todaySteps.text = "8,542 steps"
    }

    private fun loadRandomQuote() {
        val quote = quotes.random()
        binding.quoteText.text = "\"${quote.first}\""
        binding.quoteAuthor.text = "— ${quote.second}"
    }

    private fun loadUserData() {
        val sharedPreferences = requireActivity().getSharedPreferences("o2strollData", MODE_PRIVATE)
        totalMinutesInNature = sharedPreferences.getInt("totalMinutes", 0)
        currentStreak = sharedPreferences.getInt("streak", 5)
    }

    private fun saveUserData() {
        val sharedPreferences = requireActivity().getSharedPreferences("o2strollData", MODE_PRIVATE)
        sharedPreferences.edit().apply {
            putInt("totalMinutes", totalMinutesInNature)
            putInt("streak", currentStreak)
            apply()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        stopTimer()
        _binding = null
    }
}

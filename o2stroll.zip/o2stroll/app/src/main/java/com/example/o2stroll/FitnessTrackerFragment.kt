package com.example.o2stroll.fragments

import android.content.Context.MODE_PRIVATE
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.o2stroll.databinding.FragmentFitnessTrackerBinding

class FitnessTrackerFragment : Fragment() {

    private var _binding: FragmentFitnessTrackerBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFitnessTrackerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        loadFitnessData()
        setupClickListeners()
    }

    private fun loadFitnessData() {
        // Load from SharedPreferences
        val sharedPreferences = requireActivity().getSharedPreferences("FitnessData", MODE_PRIVATE)

        binding.stepsCount.text = sharedPreferences.getInt("steps", 8542).toString()
        binding.distanceCount.text = String.format("%.1f km", sharedPreferences.getFloat("distance", 6.4f))
        binding.caloriesCount.text = sharedPreferences.getInt("calories", 342).toString()
        binding.activeTimeCount.text = "${sharedPreferences.getInt("activeMinutes", 125)} min"

        // Update progress bars
        binding.stepsProgress.progress = 85
        binding.caloriesProgress.progress = 68
        binding.distanceProgress.progress = 64
    }

    private fun setupClickListeners() {
        binding.viewWeeklyReportButton.setOnClickListener {
            android.widget.Toast.makeText(context, "Weekly report coming soon!", android.widget.Toast.LENGTH_SHORT).show()
        }

        binding.syncDeviceButton.setOnClickListener {
            android.widget.Toast.makeText(context, "Syncing with fitness device...", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
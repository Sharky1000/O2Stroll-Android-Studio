package com.example.o2stroll

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.o2stroll.databinding.FragmentLoginBinding

class LoginFragment : Fragment() {

    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        (activity as? MainActivity)?.hideBottomNavigation()

        binding.loginButton.setOnClickListener {
            val email = binding.emailInput.text.toString()
            val password = binding.passwordInput.text.toString()

            if (email.isNotEmpty() && password.isNotEmpty()) {
                // Simple validation for demo
                (activity as? MainActivity)?.setLoggedIn(true)
                saveUserInfo(email)
                Toast.makeText(context, "Welcome back! 🌿", Toast.LENGTH_SHORT).show()
                (activity as? MainActivity)?.navigateToHome()
            } else {
                Toast.makeText(context, "Please fill all fields", Toast.LENGTH_SHORT).show()
            }
        }

        binding.signupText.setOnClickListener {
            (activity as? MainActivity)?.navigateToSignup()
        }

        binding.skipButton.setOnClickListener {
            Toast.makeText(context, "Continuing as guest", Toast.LENGTH_SHORT).show()
            (activity as? MainActivity)?.navigateToHome()
        }
    }

    private fun saveUserInfo(email: String) {
        val sharedPreferences = requireActivity().getSharedPreferences("o2strollPrefs", MODE_PRIVATE)
        sharedPreferences.edit().putString("userEmail", email).apply()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
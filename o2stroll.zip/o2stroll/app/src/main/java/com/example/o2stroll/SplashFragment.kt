package com.example.o2stroll

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.o2stroll.databinding.FragmentSplashBinding

class SplashFragment : Fragment() {

    private var _binding: FragmentSplashBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSplashBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        (activity as? MainActivity)?.hideBottomNavigation()

        // Animate splash screen
        binding.appLogo.alpha = 0f
        binding.appName.alpha = 0f
        binding.appTagline.alpha = 0f

        binding.appLogo.animate().alpha(1f).setDuration(1000).start()
        binding.appName.animate().alpha(1f).setDuration(1000).setStartDelay(300).start()
        binding.appTagline.animate().alpha(1f).setDuration(1000).setStartDelay(600).start()

        // Navigate after delay
        Handler(Looper.getMainLooper()).postDelayed({
            if ((activity as? MainActivity)?.isUserLoggedIn() == true) {
                (activity as? MainActivity)?.navigateToHome()
            } else {
                (activity as? MainActivity)?.navigateToLogin()
            }
        }, 3000)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

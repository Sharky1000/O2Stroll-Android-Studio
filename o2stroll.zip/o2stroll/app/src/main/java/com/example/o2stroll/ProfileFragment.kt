package com.example.o2stroll

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.o2stroll.databinding.FragmentProfileBinding

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        loadUserProfile()
        setupClickListeners()
    }

    private fun loadUserProfile() {
        val sharedPreferences = requireActivity().getSharedPreferences("o2strollPrefs", MODE_PRIVATE)
        val userName = sharedPreferences.getString("userName", "Nature Explorer")
        val userEmail = sharedPreferences.getString("userEmail", "explorer@o2stroll.com")

        binding.profileName.text = userName
        binding.profileEmail.text = userEmail

        // Load stats
        val natureData = requireActivity().getSharedPreferences("o2strollData", MODE_PRIVATE)
        binding.totalHoursValue.text = "${natureData.getInt("totalMinutes", 0) / 60}h"
        binding.currentStreakValue.text = "${natureData.getInt("streak", 5)} days"
        binding.placesVisitedValue.text = "12"
        binding.achievementsValue.text = "8"
    }

    private fun setupClickListeners() {
        binding.editProfileButton.setOnClickListener {
            Toast.makeText(context, "Edit profile feature coming soon!", Toast.LENGTH_SHORT).show()
        }

        binding.settingsOption.setOnClickListener {
            (activity as? MainActivity)?.loadFragment(SettingsFragment())
        }

        binding.historyOption.setOnClickListener {
            (activity as? MainActivity)?.loadFragment(HistoryFragment())
        }

        binding.achievementsOption.setOnClickListener {
            Toast.makeText(context, "Achievements page coming soon!", Toast.LENGTH_SHORT).show()
        }

        binding.aboutOption.setOnClickListener {
            (activity as? MainActivity)?.loadFragment(AboutFragment())
        }

        binding.logoutOption.setOnClickListener {
            showLogoutDialog()
        }
    }

    private fun showLogoutDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("Logout")
            .setMessage("Are you sure you want to logout?")
            .setPositiveButton("Yes") { _, _ ->
                logout()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun logout() {
        val sharedPreferences = requireActivity().getSharedPreferences("o2strollPrefs", MODE_PRIVATE)
        sharedPreferences.edit().putBoolean("isLoggedIn", false).apply()

        (activity as? MainActivity)?.setLoggedIn(false)
        Toast.makeText(context, "Logged out successfully", Toast.LENGTH_SHORT).show()
        (activity as? MainActivity)?.navigateToLogin()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

package com.example.o2stroll

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.o2stroll.databinding.FragmentExploreBinding

class ExploreFragment : Fragment() {

    private var _binding: FragmentExploreBinding? = null
    private val binding get() = _binding!!

    private val LOCATION_PERMISSION_REQUEST_CODE = 1001

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentExploreBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        checkLocationPermission()
        setupNearbyPlaces()
        setupClickListeners()
    }

    private fun checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                requireActivity(),
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
        } else {
            loadMap()
        }
    }

    private fun loadMap() {
        // Map integration would go here (Google Maps SDK)
        binding.mapPlaceholder.text = "🗺️\nMap View\n(Integrate Google Maps SDK)"
    }

    private fun setupNearbyPlaces() {
        // Sample data - would come from Google Places API
        val places = listOf(
            Place("Green Valley Park", "Beautiful hiking trails", "2.3 km", 4.5f),
            Place("Riverside Trail", "Scenic river walking path", "3.7 km", 4.8f),
            Place("Mountain View Point", "Perfect for sunrise watching", "5.1 km", 4.6f),
            Place("Forest Reserve", "Dense forest with wildlife", "4.2 km", 4.7f)
        )

        // Display places (in real app, use RecyclerView)
        displayPlaces(places)
    }

    private fun displayPlaces(places: List<Place>) {
        binding.placesContainer.removeAllViews()

        places.forEach { place ->
            val placeCard = layoutInflater.inflate(
                R.layout.item_nearby_place,
                binding.placesContainer,
                false
            )

            // Set place data (you'd use ViewBinding here too)
            placeCard.setOnClickListener {
                Toast.makeText(context, "Opening ${place.name}", Toast.LENGTH_SHORT).show()
            }

            binding.placesContainer.addView(placeCard)
        }
    }

    private fun setupClickListeners() {
        binding.searchButton.setOnClickListener {
            val query = binding.searchInput.text.toString()
            if (query.isNotEmpty()) {
                Toast.makeText(context, "Searching for: $query", Toast.LENGTH_SHORT).show()
            }
        }

        binding.filterParks.setOnClickListener {
            Toast.makeText(context, "Filtering: Parks", Toast.LENGTH_SHORT).show()
        }

        binding.filterTrails.setOnClickListener {
            Toast.makeText(context, "Filtering: Trails", Toast.LENGTH_SHORT).show()
        }

        binding.filterForests.setOnClickListener {
            Toast.makeText(context, "Filtering: Forests", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    data class Place(
        val name: String,
        val description: String,
        val distance: String,
        val rating: Float
    )
}
package com.example.o2stroll

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.o2stroll.databinding.FragmentSettingsBinding

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        loadSettings()
        setupListeners()
    }

    private fun loadSettings() {
        val sharedPreferences = requireActivity().getSharedPreferences("AppSettings", MODE_PRIVATE)

        binding.notificationsSwitch.isChecked = sharedPreferences.getBoolean("notifications", true)
        binding.locationSwitch.isChecked = sharedPreferences.getBoolean("location", true)
        binding.darkModeSwitch.isChecked = sharedPreferences.getBoolean("darkMode", false)
        binding.autoTrackSwitch.isChecked = sharedPreferences.getBoolean("autoTrack", false)

        binding.dailyGoalValue.text = "${sharedPreferences.getInt("dailyGoal", 3)} hours"
    }

    private fun setupListeners() {
        binding.notificationsSwitch.setOnCheckedChangeListener { _, isChecked ->
            saveSetting("notifications", isChecked)
            Toast.makeText(context, "Notifications ${if(isChecked) "enabled" else "disabled"}", Toast.LENGTH_SHORT).show()
        }

        binding.locationSwitch.setOnCheckedChangeListener { _, isChecked ->
            saveSetting("location", isChecked)
            Toast.makeText(context, "Location ${if(isChecked) "enabled" else "disabled"}", Toast.LENGTH_SHORT).show()
        }

        binding.darkModeSwitch.setOnCheckedChangeListener { _, isChecked ->
            saveSetting("darkMode", isChecked)
            Toast.makeText(context, "Dark mode ${if(isChecked) "enabled" else "disabled"}", Toast.LENGTH_SHORT).show()
        }

        binding.autoTrackSwitch.setOnCheckedChangeListener { _, isChecked ->
            saveSetting("autoTrack", isChecked)
            Toast.makeText(context, "Auto-tracking ${if(isChecked) "enabled" else "disabled"}", Toast.LENGTH_SHORT).show()
        }

        binding.changeDailyGoal.setOnClickListener {
            Toast.makeText(context, "Daily goal editor coming soon!", Toast.LENGTH_SHORT).show()
        }

        binding.languageOption.setOnClickListener {
            Toast.makeText(context, "Language settings coming soon!", Toast.LENGTH_SHORT).show()
        }

        binding.unitsOption.setOnClickListener {
            Toast.makeText(context, "Unit preferences coming soon!", Toast.LENGTH_SHORT).show()
        }

        binding.privacyOption.setOnClickListener {
            Toast.makeText(context, "Privacy policy", Toast.LENGTH_SHORT).show()
        }

        binding.backupOption.setOnClickListener {
            Toast.makeText(context, "Backup & sync coming soon!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveSetting(key: String, value: Boolean) {
        val sharedPreferences = requireActivity().getSharedPreferences("AppSettings", MODE_PRIVATE)
        sharedPreferences.edit().putBoolean(key, value).apply()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

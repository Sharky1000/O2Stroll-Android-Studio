package com.example.o2stroll

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.o2stroll.databinding.ActivityMainBinding
import com.example.o2stroll.fragments.*
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var isLoggedIn = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Check if user is logged in
        checkLoginStatus()

        // Show splash screen first
        if (savedInstanceState == null) {
            loadFragment(SplashFragment())
        }
    }

    private fun checkLoginStatus() {
        val sharedPreferences = getSharedPreferences("o2strollPrefs", MODE_PRIVATE)
        isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false)
    }

    fun navigateToLogin() {
        loadFragment(LoginFragment())
        binding.bottomNavigation.selectedItemId = R.id.nav_home
    }

    fun navigateToSignup() {
        loadFragment(SignupFragment())
    }

    fun navigateToHome() {
        loadFragment(HomeFragment())
        setupBottomNavigation()
        binding.bottomNavigation.visibility = android.view.View.VISIBLE
    }

    fun hideBottomNavigation() {
        binding.bottomNavigation.visibility = android.view.View.GONE
    }

    fun showBottomNavigation() {
        binding.bottomNavigation.visibility = android.view.View.VISIBLE
    }

    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    loadFragment(HomeFragment())
                    true
                }
                R.id.nav_explore -> {
                    loadFragment(ExploreFragment())
                    true
                }
                R.id.nav_fitness -> {
                    loadFragment(FitnessTrackerFragment())
                    true
                }
                R.id.nav_history -> {
                    loadFragment(HistoryFragment())
                    true
                }
                R.id.nav_profile -> {
                    loadFragment(ProfileFragment())
                    true
                }
                else -> false
            }
        }
    }

    fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

    fun setLoggedIn(loggedIn: Boolean) {
        isLoggedIn = loggedIn
        val sharedPreferences = getSharedPreferences("o2strollPrefs", MODE_PRIVATE)
        sharedPreferences.edit().putBoolean("isLoggedIn", loggedIn).apply()
    }

    fun isUserLoggedIn(): Boolean = isLoggedIn
}
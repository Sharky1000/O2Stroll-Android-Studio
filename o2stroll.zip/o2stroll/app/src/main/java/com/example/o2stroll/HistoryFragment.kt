package com.example.o2stroll

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.o2stroll.databinding.FragmentHistoryBinding

class HistoryFragment : Fragment() {

    private var _binding: FragmentHistoryBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHistoryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        loadHistoryData()
        setupFilters()
    }

    private fun loadHistoryData() {
        // Sample history data
        binding.weeklyTotal.text = "12h 30m"
        binding.monthlyTotal.text = "48h 15m"
        binding.yearlyTotal.text = "520h 45m"

        // Load activity history (would use RecyclerView in production)
        displayHistoryItems()
    }

    private fun displayHistoryItems() {
        val activities = listOf(
            Activity("Today", "2h 45m", "Green Valley Park", "Morning hike"),
            Activity("Yesterday", "1h 30m", "Riverside Trail", "Evening walk"),
            Activity("Oct 14", "3h 15m", "Mountain View", "Hiking trip"),
            Activity("Oct 13", "1h 00m", "City Park", "Lunch break"),
            Activity("Oct 12", "2h 20m", "Forest Reserve", "Nature photography")
        )

        // In production, use RecyclerView
        binding.historyList.removeAllViews()
        activities.forEach { activity ->
            val itemView = layoutInflater.inflate(
                R.layout.item_history,
                binding.historyList,
                false
            )
            binding.historyList.addView(itemView)
        }
    }

    private fun setupFilters() {
        binding.filterWeek.setOnClickListener {
            android.widget.Toast.makeText(context, "Showing this week", android.widget.Toast.LENGTH_SHORT).show()
        }

        binding.filterMonth.setOnClickListener {
            android.widget.Toast.makeText(context, "Showing this month", android.widget.Toast.LENGTH_SHORT).show()
        }

        binding.filterYear.setOnClickListener {
            android.widget.Toast.makeText(context, "Showing this year", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    data class Activity(
        val date: String,
        val duration: String,
        val location: String,
        val notes: String
    )
}
